from math import floor
num = float(input('Digite um número qualquer: '))
numreal = floor(num)
print('O número real para {} é {}'.format(num, numreal))
