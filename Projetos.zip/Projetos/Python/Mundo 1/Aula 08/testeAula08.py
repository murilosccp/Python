##from math import sqrt  = square root ou raiz quadrada
##num = int(input('Digite um número: '))
#raiz = sqrt(num)
#print('A raiz de {} é igual a {:.2f}'.format(num, raiz))

# // EXEMPLO 1 \\

#from math import sqrt
#n = int(input('Digite um número qualquer: '))
#raiz = sqrt(n)
#print('A raiz de {} é igual a {:.2f}'.format(n, raiz))

# // EXEMPLO 2 \\

#import random 
#num = random.randint(1, 100)
#print(num)