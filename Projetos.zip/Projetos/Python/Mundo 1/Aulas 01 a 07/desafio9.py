n = int(input('Digite o número que retorno a tabuada dele!: '))
um = n * 1
do = n * 2
tr = n * 3
qu = n * 4
ci = n * 5
s = n * 6
se = n * 7
oi = n * 8
no = n * 9
de = n * 10

print('Tabuada do {}: \n 1 X {} = {} \n 2 X {} = {} \n 3 X {} = {} \n 4 X {} = {} \n 5 X {} = {} \n 6 X {} = {} \n 7 X {} = {} \n 8 X {} = {} \n 9 X {} = {} \n 10 X {} = {}'.format(n, n, um, n, do, n, tr, n, qu, n, ci, n, s, n, se, n, oi, n, no, n, de))
 