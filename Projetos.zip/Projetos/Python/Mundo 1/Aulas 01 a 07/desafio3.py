n1 = int( input('Digite o primeiro numero = '))
n2 = int( input('Digite o segundo numero = '))
s = n1 + n2
print('A soma entre {} e {} é igual a {}'.format(n1, n2, s))













#.format utiliza uma mascará que subistitui o que ficará dentro das chaves sem a necessidade
# Utilizarmos a "," ou o "+", muito interessante e não tinha ideia. 
#print('E a nossa soma entre', n1,' e ', n2 ,'é {}'.format(s)) Sintexa antiga











##nome = input('Qual o seu nome? ')
##print('Que prazer te conhecer '+nome)
##tipos primitivos: int(inteiros), float(numeros reais, decimais), bool(valores logicos, valores true(T) e false(F))
#  e str(strings e texto)