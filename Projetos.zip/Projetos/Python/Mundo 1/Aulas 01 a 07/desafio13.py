s = float(input('Digite seu salário atual: '))
a = s * 1.15
ar = a - s
print('Com base no aumento de 15% o seu novo salário será de {:.2f} reais, um aumento de {:.2f} reais!'.format(a, ar))