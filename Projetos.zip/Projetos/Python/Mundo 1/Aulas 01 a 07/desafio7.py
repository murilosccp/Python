nota1 = float(input('Digite sua nota: '))
nota2 = float(input('Digite sua segunda nota: '))
media = (nota1 + nota2) / 2
print('Com base na suas notas, sua média é de {}'.format(media))
