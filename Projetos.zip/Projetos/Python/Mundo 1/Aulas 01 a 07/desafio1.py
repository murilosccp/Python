nome = input('Qual o seu nome?')
print('Olá '+nome+'! Seja bem vindo ao meu primeiro desafio python!!')
