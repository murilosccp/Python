v = float(input('Digite o valor que vai receber o desconto: '))
d = v * 0.95
print('Com o desconto de 5% aplicado o valor agora é de {:.2f}'.format(d))