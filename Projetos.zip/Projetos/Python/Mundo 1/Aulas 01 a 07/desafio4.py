n = input('Digite algo: ')
print('A classe desse tipo é {}'.format(type(n)))
print('Ele tem espaços? {}'.format(n.isspace()))
print('É um número? {}'.format(n.isnumeric()))
print('É uma letra? {}'.format(n.isalpha()))
print('É alfanumérico? {}'.format(n.isalnum()))
print('Está em maiúsculo? {}'.format(n.isupper()))
print('Está minunsculo? {}'.format(n.islower()))
print('Está capitalizada? {}'.format(n.istitle()))











#.isupper()