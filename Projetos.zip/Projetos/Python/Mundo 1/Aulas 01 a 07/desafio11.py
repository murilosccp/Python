l = float(input('Digite a largura em metros da parede: '))
a = float(input('Digite a altura em metros da parede: '))
ar = a * l
t = ar / 2
print('A área da parede é {} e a quantidade de tinta que será gasta é de {} litros'.format(ar, t))