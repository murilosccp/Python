n = int(input('Digite um número qualquer: '))
d = n * 2
t = n * 3
rq = n**(1/2)
print('O dobro do seu número é {} \no triplo dele é {} \ne a raiz é {:.2f}'.format(d, t, rq))
