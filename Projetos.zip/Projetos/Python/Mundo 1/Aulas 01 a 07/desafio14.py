temp = float(input("Digite a temperatura em °C: "))
f = (temp * 9 / 5) + 32
print("A temperatura de {}°C corresponde a: {}°F!".format(temp, f))