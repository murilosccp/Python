dia = input('Dia = ')
mes = input('Mês = ')
ano = input('Ano = ')

print('Que legal, então sua data de nascimento e no dia '+dia+' de '+mes+' de '+ano+'. Correto?')
