metros = int(input('Digite o valor em METROS: '))
cen = metros * 100
mil = metros * 1000
print('O valor em centimetros é de {}, enquanto o em milimetros o valor é de {}'.format(cen, mil))