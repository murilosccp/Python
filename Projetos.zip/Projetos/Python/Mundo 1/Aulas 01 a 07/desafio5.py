n = int(input('Digite um número qualquer: '))
s = n + 1
a = n - 1
print('O sucessor do número {}, é o {}, e o antecessor é o {}'.format(n, s, a))
