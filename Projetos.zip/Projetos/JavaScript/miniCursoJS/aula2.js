//const condicao = 3 < 3;

//if (condicao) {
 //   console.log("É verdade!!")
//} else {
 //   console.log("É falsoo!!")
//}

//console.log("Acabou!")


//let precoProd1 = 19.29;
//let precoProd2 = 2.80;
//let precoProd3 = 4.85;

//let caixa = 0;

//if (precoProd1 <= 18) {
//    console.log("Comprei o Produto 1")
//    caixa += precoProd1
//}

//if (precoProd2 < 3){
//  if(precoProd2 >= 1.5){
 //   console.log("Comprei o Produto 2")
 //   caixa += precoProd2
 //   }   else{
 //       console.log("Tem algo de errado com o Produto 2")
//        }
//}

//console.log("Comprei o produto 3")
//caixa += precoProd3
//console.log("Você vai pagar no total:", caixa, "reais")

function solucao(olhosNasLaterais){

olhosNasLaterais = tem = true;

 if (tem === true){
    console.log("PRESA")
 } else{
    console.log("PREDADOR")
 }
    
    }
    
    solucao()