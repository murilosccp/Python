//let nome = "Murilo";
//const idade = 20;

//console.log("Hello, world!");
// O console.log mostra uma mensagem no JS
//console.log("Amo o Borussia e o Corinthians! ass:", nome);
//console.log("Minha idade: ", idade)


//const endereco = "Av Miguel Petroni"

//let precoLeite = 9.5;
//let precoQueijo = 30;

//console.log("Preço do leite:", precoLeite);
//console.log("Preço do Queijo:", precoQueijo);


//let valor = "123";

//console.log(valor + 5);



//let precoProduto1 = 37.50;

//precoProduto1 += 1;

//console.log("O preço do produto 1 é:", precoProduto1);

//let desconto = 0.8

//precoProduto1 *= desconto;
//console.log("O novo preço do produto 1 é:", precoProduto1)

//let verdade = precoProduto1 !== 30.8;
//console.log("Será?:", verdade);

// !== é diferente === é igual
// ! = NÂO no JS.



function solucao(num1, num2){

const resto = num1 % num2;
const resposta = resto === 0;

console.log(resposta)

}

solucao()